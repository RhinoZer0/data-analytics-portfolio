Enlace a dashboard en Tabelau Public

https://public.tableau.com/views/JavierAguileraProyecto12/Dashboard1?:language=es-ES&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link